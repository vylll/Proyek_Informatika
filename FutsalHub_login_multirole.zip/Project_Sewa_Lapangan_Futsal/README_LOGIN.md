# FutsalHub — Login Multi-Role (PHP + MySQL)

## Yang ditambahkan
- Login berdasarkan email/username dan password.
- Pilihan role Admin, Pemilik Lapangan, dan Penyewa; role pilihan tetap dicocokkan dengan role di database.
- Registrasi publik hanya untuk Penyewa.
- Password disimpan memakai `password_hash()` dan diverifikasi memakai `password_verify()`.
- CSRF token untuk formulir login, registrasi, perubahan role, logout, dan pemesanan.
- Session regeneration setelah login, logout, dan pemeriksaan role di server.
- Dashboard awal dengan ringkasan data per role.
- Admin dapat mengubah role pengguna dari dashboard.
- Pesanan baru disambungkan ke akun penyewa lewat `pesanan.user_id`.

## Sebelum menjalankan
1. Buat salinan/backup database `db_futsal` terlebih dahulu.
2. Pastikan database `db_futsal` dan tabel lama `lapangan` serta `pesanan` sudah tersedia.
3. Pilih database `db_futsal` di phpMyAdmin, lalu jalankan `database/upgrade_login.sql` satu kali (script ini aman dijalankan ulang untuk kolom/index yang sudah ada).
4. Pastikan pengaturan host, username, password, dan nama database pada `config/database.php` sesuai MySQL lokalmu.
5. Dari Terminal, masuk ke folder `Project_Sewa_Lapangan_Futsal`, lalu jalankan:
   `php -S localhost:8001`
6. Buka `http://localhost:8001/index.php`.

## Membuat Admin pertama
Jalankan dari Terminal di folder proyek:
`php database/create_admin.php`

Script hanya dapat berjalan melalui CLI dan akan menolak pembuatan Admin baru jika sudah ada Admin. Gunakan password minimal 12 karakter. Setelah berhasil, buka halaman login, pilih Admin, lalu masuk.

## Membuat akun Pemilik Lapangan
- Daftarkan akun melalui registrasi sebagai Penyewa.
- Login menggunakan akun Admin, lalu ubah role akun tersebut menjadi Pemilik Lapangan.
- Untuk menautkan lapangan ke pemilik, buka phpMyAdmin dan jalankan query berikut dengan ID yang sesuai:
  `UPDATE lapangan SET owner_id = ID_PEMILIK WHERE id = ID_LAPANGAN;`
- Jangan mengganti placeholder `ID_PEMILIK`/`ID_LAPANGAN` secara literal; gunakan angka ID aktual dari tabel `users` dan `lapangan`.

## Catatan penting
- Database lama tidak dihapus dan kolom baru `pesanan.user_id` serta `lapangan.owner_id` bersifat nullable agar data lama tetap utuh.
- Halaman riwayat transaksi sekarang hanya untuk Admin.
- Penyewaan memerlukan login sebagai Penyewa.
- Dashboard ini merupakan fondasi autentikasi dan ringkasan. Fitur CRUD lengkap untuk Admin/Pemilik (misalnya tambah/edit/hapus lapangan dan pengelolaan status pembayaran) belum dibuat di versi ini.
- Untuk deployment publik, gunakan HTTPS, kredensial database khusus (bukan root), dan tinjau konfigurasi server sebelum dipublikasikan.
