<?php
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("Jalankan script ini dari Terminal, bukan browser.\n");
}
require_once __DIR__ . '/../app/models/UserModel.php';
try {
    $model = new UserModel();
    if ($model->countAdmins() > 0) {
        exit("Akun Admin sudah ada. Pembuatan Admin pertama ditolak.\n");
    }
    $ask = static function (string $label): string {
        fwrite(STDOUT, $label . ': ');
        return trim((string)fgets(STDIN));
    };
    $name = $ask('Nama Admin');
    $email = strtolower($ask('Email Admin'));
    $username = $ask('Username Admin');
    fwrite(STDOUT, 'Password Admin (minimal 12 karakter): ');
    if (function_exists('shell_exec') && stripos(PHP_OS, 'WIN') !== 0) @shell_exec('stty -echo');
    $password = trim((string)fgets(STDIN));
    if (function_exists('shell_exec') && stripos(PHP_OS, 'WIN') !== 0) @shell_exec('stty echo');
    fwrite(STDOUT, "\n");
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/^[A-Za-z0-9_.-]{3,50}$/', $username) || strlen($password) < 12) {
        exit("Input tidak valid. Password minimal 12 karakter.\n");
    }
    if ($model->emailExists($email) || $model->usernameExists($username)) exit("Email atau username sudah digunakan.\n");
    $model->createFirstAdmin($name, $email, $username, $password);
    echo "Akun Admin pertama berhasil dibuat. Silakan login melalui index.php?page=login\n";
} catch (Throwable $e) {
    fwrite(STDERR, "Gagal membuat Admin. Pastikan database dan tabel users sudah siap.\n");
    exit(1);
}
