-- FutsalHub login migration (MySQL 5.7+/8.x).
-- Pilih database db_futsal terlebih dahulu di phpMyAdmin, lalu jalankan file ini.
-- Membuat tabel users jika belum ada dan menambah kolom opsional tanpa menghapus data lama.

CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nama_lengkap VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    nomor_telepon VARCHAR(30) NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','pemilik','penyewa') NOT NULL DEFAULT 'penyewa',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @db_name = DATABASE();

SET @sql = IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='pesanan' AND COLUMN_NAME='user_id') = 0,
  'ALTER TABLE pesanan ADD COLUMN user_id INT UNSIGNED NULL',
  'SELECT ''pesanan.user_id sudah tersedia'' AS info'
);
PREPARE fh_stmt FROM @sql; EXECUTE fh_stmt; DEALLOCATE PREPARE fh_stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='pesanan' AND INDEX_NAME='idx_pesanan_user_id') = 0,
  'ALTER TABLE pesanan ADD INDEX idx_pesanan_user_id (user_id)',
  'SELECT ''Index pesanan.user_id sudah tersedia'' AS info'
);
PREPARE fh_stmt FROM @sql; EXECUTE fh_stmt; DEALLOCATE PREPARE fh_stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='lapangan' AND COLUMN_NAME='owner_id') = 0,
  'ALTER TABLE lapangan ADD COLUMN owner_id INT UNSIGNED NULL',
  'SELECT ''lapangan.owner_id sudah tersedia'' AS info'
);
PREPARE fh_stmt FROM @sql; EXECUTE fh_stmt; DEALLOCATE PREPARE fh_stmt;

SET @sql = IF(
  (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='lapangan' AND INDEX_NAME='idx_lapangan_owner_id') = 0,
  'ALTER TABLE lapangan ADD INDEX idx_lapangan_owner_id (owner_id)',
  'SELECT ''Index lapangan.owner_id sudah tersedia'' AS info'
);
PREPARE fh_stmt FROM @sql; EXECUTE fh_stmt; DEALLOCATE PREPARE fh_stmt;

-- Kolom user_id dan owner_id nullable agar data lama tetap utuh.
-- Untuk menghubungkan lapangan ke pemilik, Admin perlu mengisi lapangan.owner_id
-- dengan ID akun yang role-nya 'pemilik'.
