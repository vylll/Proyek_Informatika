# Membuat akun Admin pertama

1. Pastikan tabel `users` sudah dibuat dengan `database/upgrade_login.sql`.
2. Buka Terminal pada folder `Project_Sewa_Lapangan_Futsal`.
3. Jalankan perintah:
   `php database/create_admin.php`
4. Ikuti prompt untuk memasukkan nama, email, username, dan password.
5. Password disimpan sebagai hash. Script hanya bisa dijalankan dari Terminal/CLI dan menolak jika Admin sudah ada.

Jangan mengunggah password atau membagikannya. Setelah akun Admin dibuat, login melalui `index.php?page=login`, lalu pilih role Admin.
