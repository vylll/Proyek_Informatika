<?php
require_once __DIR__ . '/../auth_helpers.php';
require_once __DIR__ . '/../models/UserModel.php';

class AuthController {
    public function login(): void {
        $auth_error = '';
        if (current_user()) { header('Location: index.php?page=dashboard'); exit; }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) {
                $auth_error = 'Sesi formulir sudah kedaluwarsa. Muat ulang halaman dan coba lagi.';
            } else {
                $login = trim((string)($_POST['login'] ?? ''));
                $password = (string)($_POST['password'] ?? '');
                $role = (string)($_POST['role'] ?? '');
                $allowedRoles = ['admin', 'pemilik', 'penyewa'];
                $model = new UserModel();
                $user = in_array($role, $allowedRoles, true) ? $model->findByLogin($login) : null;
                if ($user && password_verify($password, $user['password_hash']) && hash_equals($user['role'], $role)) {
                    session_regenerate_id(true);
                    $_SESSION['user'] = [
                        'id' => (int)$user['id'],
                        'nama_lengkap' => $user['nama_lengkap'],
                        'email' => $user['email'],
                        'username' => $user['username'],
                        'role' => $user['role']
                    ];
                    header('Location: index.php?page=dashboard');
                    exit;
                }
                $auth_error = 'Login gagal. Periksa email/username, password, dan jenis akun yang dipilih.';
            }
        }
        require __DIR__ . '/../../views/auth/login.php';
    }

    public function register(): void {
        $auth_error = '';
        if (current_user()) { header('Location: index.php?page=dashboard'); exit; }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!verify_csrf()) {
                $auth_error = 'Sesi formulir sudah kedaluwarsa. Muat ulang halaman dan coba lagi.';
            } else {
                $name = trim((string)($_POST['nama_lengkap'] ?? ''));
                $email = strtolower(trim((string)($_POST['email'] ?? '')));
                $username = trim((string)($_POST['username'] ?? ''));
                $phone = trim((string)($_POST['nomor_telepon'] ?? ''));
                $password = (string)($_POST['password'] ?? '');
                $confirm = (string)($_POST['konfirmasi_password'] ?? '');
                if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/^[A-Za-z0-9_.-]{3,50}$/', $username)) {
                    $auth_error = 'Periksa kembali nama, format email, dan username.';
                } elseif (strlen($password) < 8) {
                    $auth_error = 'Password harus terdiri dari minimal 8 karakter.';
                } elseif ($password !== $confirm) {
                    $auth_error = 'Konfirmasi password tidak sama.';
                } else {
                    $model = new UserModel();
                    if ($model->emailExists($email)) $auth_error = 'Email tersebut sudah terdaftar.';
                    elseif ($model->usernameExists($username)) $auth_error = 'Username tersebut sudah digunakan.';
                    else {
                        try {
                            $model->createTenant($name, $email, $username, $phone, $password);
                            header('Location: index.php?page=login&registered=1');
                            exit;
                        } catch (PDOException $e) {
                            $auth_error = 'Akun belum dapat dibuat. Periksa migrasi database dan coba lagi.';
                        }
                    }
                }
            }
        }
        require __DIR__ . '/../../views/auth/register.php';
    }

    public function logout(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf()) {
            http_response_code(400);
            echo 'Permintaan logout tidak valid.';
            return;
        }
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
        header('Location: index.php');
        exit;
    }


    public function setRole(): void {
        require_role(['admin']);
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf()) {
            http_response_code(400);
            exit('Permintaan tidak valid.');
        }
        $id = (int)($_POST['user_id'] ?? 0);
        $role = (string)($_POST['role'] ?? '');
        if ($id === (int)current_user()['id'] && $role !== 'admin') {
            $_SESSION['flash_message'] = 'Role akun Admin yang sedang digunakan tidak dapat diturunkan.';
        } else {
            try {
                $model = new UserModel();
                if ($model->setRole($id, $role)) $_SESSION['flash_message'] = 'Role pengguna berhasil diperbarui.';
                else $_SESSION['flash_message'] = 'Role pengguna tidak valid.';
            } catch (Throwable $e) {
                $_SESSION['flash_message'] = 'Role belum dapat diperbarui. Periksa database.';
            }
        }
        header('Location: index.php?page=dashboard');
        exit;
    }

    public function dashboard(): void {
        require_once __DIR__ . '/../auth_helpers.php';
        require_login();
        $user = current_user();
        $stats = ['lapangan' => 0, 'pesanan' => 0, 'pengguna' => 0];
        $recent = [];
        try {
            require_once __DIR__ . '/../../config/database.php';
            $db = new Database();
            $pdo = $db->getConnection();
            if ($user['role'] === 'admin') {
                $stats['lapangan'] = (int)$pdo->query("SELECT COUNT(*) FROM lapangan")->fetchColumn();
                $stats['pesanan'] = (int)$pdo->query("SELECT COUNT(*) FROM pesanan")->fetchColumn();
                $stats['pengguna'] = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
                $recent = $pdo->query("SELECT p.*, l.nama_lapangan FROM pesanan p JOIN lapangan l ON l.id=p.id_lapangan ORDER BY p.id DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);
                $users = $pdo->query("SELECT id, nama_lengkap, email, role FROM users ORDER BY id DESC LIMIT 8")->fetchAll(PDO::FETCH_ASSOC);
            } elseif ($user['role'] === 'pemilik') {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM lapangan WHERE owner_id = ?");
                $stmt->execute([$user['id']]); $stats['lapangan'] = (int)$stmt->fetchColumn();
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM pesanan p JOIN lapangan l ON l.id=p.id_lapangan WHERE l.owner_id = ?");
                $stmt->execute([$user['id']]); $stats['pesanan'] = (int)$stmt->fetchColumn();
                $stmt = $pdo->prepare("SELECT p.*, l.nama_lapangan FROM pesanan p JOIN lapangan l ON l.id=p.id_lapangan WHERE l.owner_id = ? ORDER BY p.id DESC LIMIT 6");
                $stmt->execute([$user['id']]); $recent = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } else {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM pesanan WHERE user_id = ?");
                $stmt->execute([$user['id']]); $stats['pesanan'] = (int)$stmt->fetchColumn();
                $stmt = $pdo->prepare("SELECT p.*, l.nama_lapangan FROM pesanan p JOIN lapangan l ON l.id=p.id_lapangan WHERE p.user_id = ? ORDER BY p.id DESC LIMIT 6");
                $stmt->execute([$user['id']]); $recent = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
        } catch (Throwable $e) {
            $dashboard_warning = 'Database belum siap. Jalankan file migrasi database/upgrade_login.sql sebelum menggunakan dashboard.';
            $users = [];
        }
        require __DIR__ . '/../../views/dashboard/index.php';
    }
}
