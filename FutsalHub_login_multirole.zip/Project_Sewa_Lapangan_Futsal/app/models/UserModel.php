<?php
require_once __DIR__ . '/../../config/database.php';

class UserModel extends Database {
    public function findByLogin(string $login): ?array {
        $stmt = $this->db->prepare("SELECT id, nama_lengkap, email, username, password_hash, role FROM users WHERE email = :login OR username = :login LIMIT 1");
        $stmt->execute([':login' => $login]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        return $user ?: null;
    }

    public function emailExists(string $email): bool {
        $stmt = $this->db->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        return (bool)$stmt->fetchColumn();
    }

    public function usernameExists(string $username): bool {
        $stmt = $this->db->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        return (bool)$stmt->fetchColumn();
    }

    public function createTenant(string $name, string $email, string $username, string $phone, string $password): bool {
        $stmt = $this->db->prepare("INSERT INTO users (nama_lengkap, email, username, nomor_telepon, password_hash, role) VALUES (:name, :email, :username, :phone, :hash, 'penyewa')");
        return $stmt->execute([
            ':name' => $name, ':email' => $email, ':username' => $username,
            ':phone' => $phone ?: null, ':hash' => password_hash($password, PASSWORD_DEFAULT)
        ]);
    }

    public function countAdmins(): int {
        return (int)$this->db->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
    }

    public function getAllUsers(): array {
        return $this->db->query("SELECT id, nama_lengkap, email, username, nomor_telepon, role, created_at FROM users ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function createFirstAdmin(string $name, string $email, string $username, string $password): bool {
        $stmt = $this->db->prepare("INSERT INTO users (nama_lengkap, email, username, password_hash, role) VALUES (?, ?, ?, ?, 'admin')");
        return $stmt->execute([$name, $email, $username, password_hash($password, PASSWORD_DEFAULT)]);
    }

    public function setRole(int $id, string $role): bool {
        if (!in_array($role, ['admin', 'pemilik', 'penyewa'], true)) return false;
        $stmt = $this->db->prepare("UPDATE users SET role = ? WHERE id = ?");
        return $stmt->execute([$role, $id]);
    }
}
