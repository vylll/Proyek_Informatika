<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params([
        'httponly' => true,
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'samesite' => 'Lax'
    ]);
    session_start();
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
function h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . h($_SESSION['csrf_token'] ?? '') . '">';
}
function verify_csrf(): bool {
    return isset($_POST['csrf_token'], $_SESSION['csrf_token']) &&
        hash_equals($_SESSION['csrf_token'], (string)$_POST['csrf_token']);
}
function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}
function require_login(): void {
    if (!current_user()) {
        header('Location: index.php?page=login');
        exit;
    }
}
function require_role(array $roles): void {
    require_login();
    if (!in_array(current_user()['role'] ?? '', $roles, true)) {
        http_response_code(403);
        echo '<!doctype html><html lang="id"><meta charset="utf-8"><title>Akses ditolak</title><body style="font-family:Arial;padding:3rem"><h1>Akses ditolak</h1><p>Akunmu tidak memiliki izin untuk membuka halaman ini.</p><a href="index.php">Kembali ke beranda</a></body></html>';
        exit;
    }
}
function role_label(string $role): string {
    return ['admin' => 'Admin', 'pemilik' => 'Pemilik Lapangan', 'penyewa' => 'Penyewa'][$role] ?? 'Pengguna';
}
