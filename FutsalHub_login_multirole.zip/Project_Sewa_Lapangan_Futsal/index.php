<?php
// Buffer output agar header("Location: ...") di controller tetap bisa berjalan
// walaupun navbar sudah dicetak sebelumnya.
ob_start();
require_once 'app/auth_helpers.php';

// --- BARIS CRITICAL: Inisialisasi variabel $page agar tidak Undefined ---
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

$judul_halaman = [
    'home'     => 'FutsalHub — Main Futsal, Tanpa Ribet',
    'lapangan' => 'Pilih Lapangan — FutsalHub',
    'sewa'     => 'Form Pemesanan — FutsalHub',
    'jadwal'   => 'Jadwal Lapangan — FutsalHub',
    'riwayat'  => 'Riwayat Transaksi — FutsalHub',
    'login' => 'Masuk — FutsalHub',
    'register' => 'Daftar — FutsalHub',
    'dashboard' => 'Dashboard — FutsalHub',
];
$title = isset($judul_halaman[$page]) ? $judul_halaman[$page] : 'FutsalHub';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title); ?></title>
    <meta name="description" content="FutsalHub — temukan lapangan futsal, cek jadwal yang tersedia, dan pesan dengan mudah.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wght@600;700;800;900&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/futsalhub.css">
</head>
<body class="fh-body">

<nav class="navbar navbar-expand-lg fh-nav">
    <div class="container">
        <a class="fh-brand" href="index.php" aria-label="FutsalHub beranda">
            <span class="fh-brand-mark" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7l4 3-1.5 4.5h-5L8 10z"/><path d="M12 3v4M21 10l-5 0M3 10h5M7 20l2.5-5.5M17 20l-2.5-5.5"/></svg>
            </span>
            <span>Futsal<span class="fh-brand-accent">Hub</span></span>
        </a>
        <button class="navbar-toggler fh-nav-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Buka menu">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h10"/></svg>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <li class="nav-item">
                    <a class="nav-link <?= $page == 'home' ? 'active' : '' ?>" <?= $page == 'home' ? 'aria-current="page"' : '' ?> href="index.php">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($page == 'lapangan' || $page == 'sewa') ? 'active' : '' ?>" <?= $page == 'lapangan' ? 'aria-current="page"' : '' ?> href="index.php?page=lapangan">Lapangan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $page == 'jadwal' ? 'active' : '' ?>" <?= $page == 'jadwal' ? 'aria-current="page"' : '' ?> href="index.php?page=jadwal">Jadwal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $page == 'riwayat' ? 'active' : '' ?>" <?= $page == 'riwayat' ? 'aria-current="page"' : '' ?> href="index.php?page=riwayat">Riwayat <small class="fh-text-muted">(Admin)</small></a>
                </li>
                <?php if (current_user()): ?>
                <li class="nav-item ms-lg-3"><a class="fh-btn fh-btn-outline fh-btn-sm fh-nav-cta" href="index.php?page=dashboard"><?= htmlspecialchars(current_user()['nama_lengkap'], ENT_QUOTES, 'UTF-8') ?></a></li>
                <?php else: ?>
                <li class="nav-item ms-lg-3"><a class="fh-btn fh-btn-outline fh-btn-sm fh-nav-cta" href="index.php?page=login">Masuk</a></li>
                <li class="nav-item ms-lg-2"><a class="fh-btn fh-btn-primary fh-btn-sm fh-nav-cta" href="index.php?page=register">Daftar</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<main class="fh-main">
<?php
if (in_array($page, ['login', 'register', 'logout', 'dashboard', 'set_role'], true)) {
    require_once 'app/controllers/AuthController.php';
    $auth = new AuthController();
    if ($page === 'login') $auth->login();
    elseif ($page === 'register') $auth->register();
    elseif ($page === 'logout') $auth->logout();
    elseif ($page === 'set_role') $auth->setRole();
    else $auth->dashboard();
} elseif ($page === 'riwayat') {
    require_role(['admin']);
    require_once 'app/controllers/LapanganControllers.php';
    (new LapanganController())->riwayatSewa();
} elseif ($page === 'lapangan') {
    require_once 'app/controllers/LapanganControllers.php';
    (new LapanganController())->index();
} elseif ($page === 'sewa' || $page === 'proses_sewa') {
    require_role(['penyewa']);
    require_once 'app/controllers/LapanganControllers.php';
    $controller = new LapanganController();
    if ($page === 'sewa') $controller->formSewa();
    else $controller->prosesSewa();
} elseif ($page === 'jadwal') {
    require_once 'app/controllers/LapanganControllers.php';
    (new LapanganController())->jadwalPublic();
} else {
    require_once 'views/lapangan/home.php';
}
?>
</main>

<footer class="fh-footer <?= $page == 'home' ? 'fh-footer-tight' : '' ?>">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-5">
                <a class="fh-brand mb-3" href="index.php">
                    <span class="fh-brand-mark" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7l4 3-1.5 4.5h-5L8 10z"/></svg>
                    </span>
                    FutsalHub
                </a>
                <p class="mt-3 mb-0" style="max-width:360px">Platform penyewaan lapangan futsal. Pilih lapangan, cek jadwal, dan pesan dalam beberapa langkah.</p>
            </div>
            <div class="col-6 col-lg-3 offset-lg-1">
                <h6>Navigasi</h6>
                <ul>
                    <li><a href="index.php">Beranda</a></li>
                    <li><a href="index.php?page=lapangan">Lapangan</a></li>
                    <li><a href="index.php?page=jadwal">Jadwal</a></li>
                    <li><a href="index.php?page=riwayat">Riwayat</a></li>
                </ul>
            </div>
            <div class="col-6 col-lg-3">
                <h6>Mulai</h6>
                <ul>
                    <li><a href="index.php?page=lapangan">Pesan Lapangan</a></li>
                    <li><a href="index.php?page=jadwal">Cek Slot Kosong</a></li>
                </ul>
            </div>
        </div>
        <div class="fh-footer-bottom">
            <span>&copy; <?= date('Y'); ?> FutsalHub. Semua hak dilindungi.</span>
            <span>Main futsal, tanpa ribet.</span>
        </div>
    </div>
</footer>

<script>
document.querySelectorAll('[data-password-toggle]').forEach(function(button) {
  button.addEventListener('click', function() {
    var input = document.getElementById(button.getAttribute('data-password-toggle'));
    if (!input) return;
    var showing = input.type === 'password';
    input.type = showing ? 'text' : 'password';
    button.textContent = showing ? 'Sembunyi' : 'Lihat';
    button.setAttribute('aria-label', showing ? 'Sembunyikan password' : 'Tampilkan password');
  });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php ob_end_flush(); ?>
