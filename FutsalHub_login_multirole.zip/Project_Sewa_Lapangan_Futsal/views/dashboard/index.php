<?php
$role = $user['role'] ?? 'penyewa';
?>
<section class="fh-page-head">
  <div class="container d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3">
    <div><span class="fh-eyebrow"><?= h(role_label($role)) ?></span><h1>Halo, <?= h($user['nama_lengkap'] ?? 'Pengguna') ?> 👋</h1><p>Selamat datang di dashboard FutsalHub. Berikut ringkasan aktivitas akunmu.</p></div>
    <form method="post" action="index.php?page=logout"><?= csrf_field() ?><button class="fh-btn fh-btn-outline" type="submit">Keluar akun</button></form>
  </div>
</section>
<section class="fh-section-sm"><div class="container">
  <?php if (!empty($_SESSION['flash_message'])): ?><div class="alert alert-info"><?= h($_SESSION['flash_message']) ?></div><?php unset($_SESSION['flash_message']); endif; ?>\n  <?php if (!empty($dashboard_warning)): ?><div class="alert alert-warning"><?= h($dashboard_warning) ?></div><?php endif; ?>
  <div class="row g-3 mb-4">
    <?php if ($role !== 'penyewa'): ?><div class="col-md-4"><div class="fh-stat-card"><span>Lapangan<?= $role === 'pemilik' ? ' saya' : '' ?></span><strong><?= (int)$stats['lapangan'] ?></strong><small>Data lapangan terdaftar</small></div></div><?php endif; ?>
    <div class="col-md-4"><div class="fh-stat-card"><span><?= $role === 'penyewa' ? 'Pesanan saya' : 'Total pesanan' ?></span><strong><?= (int)$stats['pesanan'] ?></strong><small>Pesanan yang dapat kamu akses</small></div></div>
    <?php if ($role === 'admin'): ?><div class="col-md-4"><div class="fh-stat-card"><span>Total pengguna</span><strong><?= (int)$stats['pengguna'] ?></strong><small>Semua role</small></div></div><?php endif; ?>
  </div>
  <div class="fh-dashboard-actions mb-4">
    <?php if ($role === 'penyewa'): ?><a class="fh-btn fh-btn-primary" href="index.php?page=lapangan">Cari &amp; pesan lapangan →</a><a class="fh-btn fh-btn-outline" href="index.php?page=jadwal">Lihat jadwal publik</a><?php endif; ?>
    <?php if ($role === 'pemilik'): ?><div class="alert alert-info mb-0">Data lapangan akan muncul di dashboard ini setelah kolom pemilik ditautkan dan lapangan diberikan kepada akunmu oleh Admin.</div><?php endif; ?>
    <?php if ($role === 'admin'): ?><a class="fh-btn fh-btn-primary" href="index.php?page=riwayat">Kelola transaksi →</a><a class="fh-btn fh-btn-outline" href="index.php?page=lapangan">Lihat daftar lapangan</a><?php endif; ?>
  </div>
  <div class="fh-table-wrap">
    <div class="fh-table-heading"><h2><?= $role === 'penyewa' ? 'Pesanan Terbaru Saya' : 'Pesanan Terbaru' ?></h2></div>
    <table class="fh-table"><thead><tr><th>Nama pemesan</th><th>Lapangan</th><th>Tanggal</th><th>Jam</th></tr></thead><tbody>
    <?php if (empty($recent)): ?><tr><td colspan="4" class="fh-empty-row">Belum ada data pesanan untuk ditampilkan.</td></tr>
    <?php else: foreach ($recent as $item): ?><tr><td><?= h($item['nama_pemesan']) ?></td><td><?= h($item['nama_lapangan']) ?></td><td><?= h($item['tanggal_sewa']) ?></td><td><?= h(date('H:i', strtotime($item['jam_mulai']))) ?> · <?= (int)$item['durasi_jam'] ?> jam</td></tr><?php endforeach; endif; ?>
    </tbody></table>
  </div>
  <?php if ($role === 'admin' && !empty($users)): ?><div class="fh-table-wrap mt-4"><div class="fh-table-heading"><h2>Kelola Role Pengguna</h2><p class="fh-text-muted mb-0 mt-2">Ubah jenis akun dengan hati-hati. Registrasi publik tetap hanya membuat akun Penyewa.</p></div><table class="fh-table"><thead><tr><th>Nama</th><th>Email</th><th>Role</th><th>Ubah role</th></tr></thead><tbody><?php foreach($users as $u): ?><tr><td><?= h($u['nama_lengkap']) ?></td><td><?= h($u['email']) ?></td><td><?= h(role_label($u['role'])) ?></td><td><form method="post" action="index.php?page=set_role" class="d-flex gap-2 flex-wrap"><?= csrf_field() ?><input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>"><select class="form-select" name="role" aria-label="Role pengguna" style="max-width:190px"><?php foreach(['penyewa'=>'Penyewa','pemilik'=>'Pemilik Lapangan','admin'=>'Admin'] as $rk=>$rl): ?><option value="<?= h($rk) ?>" <?= $u['role']===$rk?'selected':'' ?>><?= h($rl) ?></option><?php endforeach; ?></select><button type="submit" class="fh-btn fh-btn-outline fh-btn-sm">Simpan</button></form></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div></section>
