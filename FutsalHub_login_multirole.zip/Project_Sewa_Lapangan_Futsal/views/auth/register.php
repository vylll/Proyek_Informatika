<section class="fh-auth-shell fh-auth-register">
  <div class="fh-auth-card">
    <a class="fh-brand mb-4" href="index.php"><span class="fh-brand-mark">⚽</span><span>Futsal<span class="fh-brand-accent">Hub</span></span></a>
    <span class="fh-eyebrow">Buat akun baru</span><h1>Mulai booking lebih mudah</h1>
    <p class="fh-auth-intro">Registrasi publik hanya tersedia untuk akun penyewa.</p>
    <?php if (!empty($auth_error)): ?><div class="alert alert-danger" role="alert"><?= h($auth_error) ?></div><?php endif; ?>
    <form method="post" action="index.php?page=register" class="fh-form">
      <?= csrf_field() ?>
      <div class="mb-3"><label class="form-label" for="nama">Nama lengkap</label><input class="form-control" id="nama" name="nama_lengkap" required maxlength="120" value="<?= h($_POST['nama_lengkap'] ?? '') ?>"></div>
      <div class="mb-3"><label class="form-label" for="email">Email</label><input class="form-control" id="email" type="email" name="email" required maxlength="190" value="<?= h($_POST['email'] ?? '') ?>"></div>
      <div class="mb-3"><label class="form-label" for="username">Username</label><input class="form-control" id="username" name="username" required minlength="3" maxlength="50" pattern="[A-Za-z0-9_.-]+" value="<?= h($_POST['username'] ?? '') ?>"><div class="form-text">Gunakan huruf, angka, titik, garis bawah, atau tanda hubung.</div></div>
      <div class="mb-3"><label class="form-label" for="telepon">Nomor telepon (opsional)</label><input class="form-control" id="telepon" name="nomor_telepon" maxlength="30" value="<?= h($_POST['nomor_telepon'] ?? '') ?>"></div>
      <div class="mb-3"><label class="form-label" for="password">Password</label><div class="fh-password-wrap"><input class="form-control" id="password" type="password" name="password" minlength="8" autocomplete="new-password" required><button type="button" class="fh-password-toggle" data-password-toggle="password">Lihat</button></div><div class="form-text">Minimal 8 karakter.</div></div>
      <div class="mb-3"><label class="form-label" for="confirm">Konfirmasi password</label><input class="form-control" id="confirm" type="password" name="konfirmasi_password" minlength="8" autocomplete="new-password" required></div>
      <button class="fh-btn fh-btn-primary fh-btn-block" type="submit">Buat akun penyewa →</button>
    </form>
    <p class="fh-auth-bottom">Sudah punya akun? <a href="index.php?page=login">Masuk di sini</a></p><a class="fh-back-link" href="index.php">← Kembali ke FutsalHub</a>
  </div>
  <div class="fh-auth-aside"><div><span class="fh-hero-badge">Your next game</span><h2>Waktunya<br><em>turun ke lapangan.</em></h2><p>Buat akun untuk mengakses pengalaman penyewaan lapangan yang lebih personal.</p></div></div>
</section>
