<?php $selectedRole = $_GET['role'] ?? ($_POST['role'] ?? 'penyewa'); if (!in_array($selectedRole, ['admin','pemilik','penyewa'], true)) $selectedRole = 'penyewa'; ?>
<section class="fh-auth-shell">
  <div class="fh-auth-card">
    <a class="fh-brand mb-4" href="index.php"><span class="fh-brand-mark">⚽</span><span>Futsal<span class="fh-brand-accent">Hub</span></span></a>
    <span class="fh-eyebrow">Selamat datang kembali</span>
    <h1>Masuk ke akunmu</h1>
    <p class="fh-auth-intro">Pilih jenis akun, lalu masukkan informasi login.</p>
    <?php if (isset($_GET['registered'])): ?><div class="alert alert-success" role="status">Registrasi berhasil. Silakan masuk menggunakan akunmu.</div><?php endif; ?>\n    <?php if (!empty($auth_error)): ?><div class="alert alert-danger" role="alert"><?= h($auth_error) ?></div><?php endif; ?>
    <div class="fh-role-grid" role="group" aria-label="Jenis akun">
      <?php foreach (['penyewa'=>'Penyewa','pemilik'=>'Pemilik Lapangan','admin'=>'Admin'] as $key=>$label): ?>
      <a class="fh-role-option <?= $selectedRole === $key ? 'is-active' : '' ?>" href="index.php?page=login&amp;role=<?= h($key) ?>">
        <span class="fh-role-icon"><?= $key === 'admin' ? '⚙' : ($key === 'pemilik' ? '⌂' : '⚽') ?></span><strong><?= h($label) ?></strong>
      </a>
      <?php endforeach; ?>
    </div>
    <form method="post" action="index.php?page=login" class="fh-form mt-4">
      <?= csrf_field() ?>
      <input type="hidden" name="role" value="<?= h($selectedRole) ?>">
      <div class="mb-3"><label class="form-label" for="login">Email atau username</label><input class="form-control" id="login" name="login" autocomplete="username" required value="<?= h($_POST['login'] ?? '') ?>" placeholder="nama@email.com"></div>
      <div class="mb-3"><label class="form-label" for="password">Password</label><div class="fh-password-wrap"><input class="form-control" id="password" type="password" name="password" autocomplete="current-password" required placeholder="Masukkan password"><button type="button" class="fh-password-toggle" data-password-toggle="password" aria-label="Tampilkan password">Lihat</button></div></div>
      <button class="fh-btn fh-btn-primary fh-btn-block" type="submit">Masuk sebagai <?= h(role_label($selectedRole)) ?> <span aria-hidden="true">→</span></button>
    </form>
    <p class="fh-auth-bottom">Belum punya akun? <a href="index.php?page=register">Daftar sebagai penyewa</a></p>
    <a class="fh-back-link" href="index.php">← Kembali ke FutsalHub</a>
  </div>
  <div class="fh-auth-aside"><div><span class="fh-hero-badge">Play better</span><h2>Temukan lapangan.<br><em>Bangun momen.</em></h2><p>Semua kebutuhan futsalmu, dari memilih lapangan sampai mengatur jadwal, dalam satu tempat.</p></div></div>
</section>
