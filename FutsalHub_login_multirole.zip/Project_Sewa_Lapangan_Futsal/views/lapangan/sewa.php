<section class="fh-page-head">
    <div class="container">
        <span class="fh-eyebrow">Pemesanan</span>
        <h1>Form Pemesanan &amp; Pembayaran</h1>
        <p>Isi data, pilih jadwal, lalu unggah bukti pembayaran untuk mengamankan slot timmu.</p>
    </div>
</section>

<section class="fh-section-sm">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-xl-7">
                <div class="fh-panel">
                    <div class="fh-panel-body">

                        <div class="fh-summary">
                            <div>
                                <small>Lapangan dipilih</small>
                                <strong><?= htmlspecialchars($nama_lapangan); ?></strong>
                            </div>
                            <span class="fh-badge fh-badge-qris">Rp <?= number_format($harga_per_jam, 0, ',', '.'); ?> / jam</span>
                        </div>

                        <form action="index.php?page=proses_sewa" method="POST" enctype="multipart/form-data" class="fh-form">
                            <?= csrf_field(); ?>

                            <input type="hidden" name="id_lapangan" value="<?= htmlspecialchars($id_lapangan); ?>">

                            <div class="fh-step"><span>1</span> Data &amp; Jadwal</div>

                            <div class="mb-3">
                                <label class="form-label" for="namaPemesan">Nama Pemesan / Tim</label>
                                <input type="text" id="namaPemesan" name="nama_pemesan" class="form-control" placeholder="Masukkan nama lengkap" required>
                            </div>

                            <div class="row g-3">
                                <div class="col-sm-6 col-md-5">
                                    <label class="form-label" for="tanggalSewa">Tanggal Sewa</label>
                                    <input type="date" id="tanggalSewa" name="tanggal_sewa" class="form-control" required>
                                </div>
                                <div class="col-6 col-md-4">
                                    <label class="form-label" for="jamMulai">Jam Mulai</label>
                                    <input type="time" id="jamMulai" name="jam_mulai" class="form-control" required>
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label" for="durasiJam">Durasi (jam)</label>
                                    <input type="number" id="durasiJam" name="durasi_jam" class="form-control" min="1" max="12" value="1" required>
                                </div>
                            </div>
                            <div class="form-text mt-2">Belum yakin jam berapa yang kosong? <a href="index.php?page=jadwal" target="_blank" rel="noopener">Cek jadwal publik</a>.</div>

                            <hr class="fh-divider">

                            <div class="fh-step"><span>2</span> Pembayaran</div>

                            <div class="fh-total">
                                <div>
                                    <small>Total biaya</small>
                                    <span class="fh-total-calc"><span id="durasiTeks">1</span> jam × Rp <?= number_format($harga_per_jam, 0, ',', '.'); ?></span>
                                </div>
                                <strong>Rp <span id="totalBiayaTeks"><?= number_format($harga_per_jam, 0, ',', '.'); ?></span></strong>
                            </div>

                            <label class="form-label" for="pilihanBayar">Metode Pembayaran</label>
                            <!-- Select asli tetap dikirim ke backend (name="jenis_pembayaran") -->
                            <select name="jenis_pembayaran" id="pilihanBayar" class="form-select mb-3" required>
                                <option value="">-- Pilih Metode --</option>
                                <option value="QRIS">QRIS (Otomatis)</option>
                                <option value="Transfer Bank">Transfer Bank (Manual)</option>
                            </select>

                            <div id="kotakQris" class="fh-pay-box text-center d-none">
                                <h4>Scan QRIS di bawah ini</h4>
                                <div class="fh-qr">
                                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=FutsalHub_Payment" alt="Kode QRIS Pembayaran">
                                </div>
                                <div class="fh-note text-start">Pastikan nominal pembayaran sesuai dengan total harga sewa.</div>
                            </div>

                            <div id="kotakTransfer" class="fh-pay-box d-none">
                                <h4>Informasi Rekening Transfer</h4>
                                <div class="fh-bank-row"><span>Nama Bank</span><strong>Bank Central Asia (BCA)</strong></div>
                                <div class="fh-bank-row"><span>Nomor Rekening</span><strong>872-0948-231</strong></div>
                                <div class="fh-bank-row"><span>Atas Nama</span><strong>FUTSALHUB INDONESIA</strong></div>
                                <div class="fh-note">Simpan bukti transfer (struk atau m-banking) untuk diunggah di bawah.</div>
                            </div>

                            <div class="mb-1">
                                <label class="form-label" for="buktiBayar">Unggah Bukti Transfer / QRIS (Foto)</label>
                                <input type="file" id="buktiBayar" name="bukti_pembayaran" class="form-control" accept="image/*" required>
                                <div class="form-text">Format: JPG, JPEG, atau PNG. Maks 2MB.</div>
                            </div>

                            <div class="fh-form-actions">
                                <a href="index.php?page=lapangan" class="fh-btn fh-btn-outline">Batal</a>
                                <button type="submit" class="fh-btn fh-btn-lime fh-btn-lg">Konfirmasi &amp; Bayar</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    // Ambil harga dasar lapangan dari variabel PHP
    const hargaPerJam = <?= (int) $harga_per_jam; ?>;

    const durasiJamInput = document.getElementById('durasiJam');
    const totalBiayaTeks = document.getElementById('totalBiayaTeks');
    const durasiTeks = document.getElementById('durasiTeks');

    const pilihanBayar = document.getElementById('pilihanBayar');
    const kotakQris = document.getElementById('kotakQris');
    const kotakTransfer = document.getElementById('kotakTransfer');

    // --- LOGIKA 1: KALKULATOR HARGA LIVE ---
    durasiJamInput.addEventListener('input', function() {
        let durasi = parseInt(this.value);
        if (isNaN(durasi) || durasi < 1) {
            durasi = 1;
        }
        const total = durasi * hargaPerJam;
        totalBiayaTeks.innerText = total.toLocaleString('id-ID');
        durasiTeks.innerText = durasi;
    });

    // --- LOGIKA 2: DETEKSI DROPDOWN PEMBAYARAN ---
    pilihanBayar.addEventListener('change', function() {
        if (this.value === 'QRIS') {
            kotakQris.classList.remove('d-none');
            kotakTransfer.classList.add('d-none');
        } else if (this.value === 'Transfer Bank') {
            kotakTransfer.classList.remove('d-none');
            kotakQris.classList.add('d-none');
        } else {
            kotakQris.classList.add('d-none');
            kotakTransfer.classList.add('d-none');
        }
    });
</script>
