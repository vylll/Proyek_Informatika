<section class="fh-page-head">
    <div class="container">
        <span class="fh-eyebrow">Panel Admin</span>
        <h1>Riwayat Transaksi Masuk</h1>
        <p>Gunakan halaman ini untuk memvalidasi pembayaran transfer bank dan QRIS dari pelanggan.</p>
    </div>
</section>

<section class="fh-section-sm">
    <div class="container">
        <div class="fh-table-wrap">
            <table class="fh-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pemesan</th>
                        <th>Lapangan</th>
                        <th>Tanggal Sewa</th>
                        <th>Jam &amp; Durasi</th>
                        <th>Metode</th>
                        <th>Bukti</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($data_pesanan)) : ?>
                        <tr><td colspan="7" class="fh-empty-row">Belum ada transaksi masuk.</td></tr>
                    <?php else : ?>
                        <?php $no = 1; foreach ($data_pesanan as $pesanan) : ?>
                            <tr>
                                <td data-label="No" class="fh-text-muted"><?= $no++; ?></td>
                                <td data-label="Pemesan" class="fh-cell-strong"><?= htmlspecialchars($pesanan['nama_pemesan']); ?></td>
                                <td data-label="Lapangan"><?= htmlspecialchars($pesanan['nama_lapangan']); ?></td>
                                <td data-label="Tanggal"><?= htmlspecialchars($pesanan['tanggal_sewa']); ?></td>
                                <td data-label="Jam"><span class="fh-badge fh-badge-time"><?= date('H:i', strtotime($pesanan['jam_mulai'])); ?> WIB · <?= htmlspecialchars($pesanan['durasi_jam']); ?> jam</span></td>
                                <td data-label="Metode"><span class="fh-badge <?= $pesanan['jenis_pembayaran'] == 'QRIS' ? 'fh-badge-qris' : 'fh-badge-bank' ?>"><?= htmlspecialchars($pesanan['jenis_pembayaran']); ?></span></td>
                                <td data-label="Bukti">
                                    <?php if (!empty($pesanan['bukti_pembayaran'])) : ?>
                                        <a href="assets/uploads/<?= htmlspecialchars($pesanan['bukti_pembayaran']); ?>" target="_blank" rel="noopener" class="fh-btn fh-btn-outline fh-btn-sm">Lihat Struk</a>
                                    <?php else : ?>
                                        <span class="fh-text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
