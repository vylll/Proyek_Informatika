<section class="fh-page-head">
    <div class="container d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3">
        <div>
            <span class="fh-eyebrow">Daftar Lapangan</span>
            <h1>Pilihan Lapangan Futsal</h1>
            <p>Bandingkan ukuran dan harga, lalu pesan lapangan yang paling cocok untuk timmu.</p>
        </div>
        <a href="index.php?page=riwayat" class="fh-btn fh-btn-outline">Riwayat Pemesanan</a>
    </div>
</section>

<section class="fh-section-sm">
    <div class="container">
        <?php if (empty($data_lapangan)) : ?>
            <div class="fh-empty">Belum ada data lapangan yang tersedia.</div>
        <?php else : ?>
        <div class="row g-4">
            <?php foreach ($data_lapangan as $lapangan) : ?>
                <div class="col-sm-6 col-lg-4">
                    <article class="fh-field-card">
                        <div class="fh-field-media">
                            <div class="fh-field-fallback" aria-hidden="true">
                                <svg viewBox="0 0 100 60" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="2" width="96" height="56" rx="2"/><path d="M50 2v56"/><circle cx="50" cy="30" r="9"/><rect x="2" y="18" width="12" height="24"/><rect x="86" y="18" width="12" height="24"/></svg>
                            </div>
                            <img src="assets/img/lapangan<?= $lapangan['id']; ?>.jpg" alt="Foto <?= htmlspecialchars($lapangan['nama_lapangan']); ?>" loading="lazy" onerror="this.remove()" style="position:relative">
                            <span class="fh-field-chip">Ukuran <?= htmlspecialchars($lapangan['ukuran']); ?></span>
                        </div>
                        <div class="fh-field-body">
                            <h3><?= htmlspecialchars($lapangan['nama_lapangan']); ?></h3>
                            <div class="fh-price">
                                <strong>Rp <?= number_format($lapangan['harga_per_jam'], 0, ',', '.'); ?></strong>
                                <span>/ jam</span>
                            </div>
                            <div class="fh-field-actions">
                                <button type="button" class="fh-btn fh-btn-outline" data-bs-toggle="modal" data-bs-target="#modalDetail<?= $lapangan['id']; ?>">Lihat Detail</button>
                                <a href="index.php?page=sewa&id=<?= $lapangan['id']; ?>" class="fh-btn fh-btn-primary">Pesan</a>
                            </div>
                        </div>
                    </article>
                </div>

                <div class="modal fade fh-modal" id="modalDetail<?= $lapangan['id']; ?>" tabindex="-1" aria-labelledby="modalTitle<?= $lapangan['id']; ?>" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalTitle<?= $lapangan['id']; ?>"><?= htmlspecialchars($lapangan['nama_lapangan']); ?></h5>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
                            </div>
                            <div class="modal-body">
                                <img src="assets/img/lapangan<?= $lapangan['id']; ?>.jpg" class="fh-modal-img" alt="Foto <?= htmlspecialchars($lapangan['nama_lapangan']); ?>" loading="lazy" onerror="this.remove()">

                                <p class="fh-spec-label">Deskripsi Fisik</p>
                                <ul class="fh-list">
                                    <li><strong>Ukuran standar:</strong> <?= htmlspecialchars($lapangan['ukuran']); ?></li>
                                    <li><strong>Jenis lantai:</strong> <?= $lapangan['id'] == 1 ? 'Matras Interlock Pro (Sangat Empuk & Anti Slip)' : ($lapangan['id'] == 2 ? 'Rumput Sintetis Monofilament (Mirip Lapangan Asli)' : 'Vinil Premium (Standar Turnamen Internasional)'); ?></li>
                                </ul>

                                <p class="fh-spec-label">Benefit Sewa</p>
                                <ul class="fh-list mb-0">
                                    <li>Gratis peminjaman 2 buah Bola Futsal Specs Pro.</li>
                                    <li>Gratis sewa 1 set Rompi Tim (10 Pcs).</li>
                                    <li>Fasilitas ruang ganti AC &amp; Shower Air Hangat.</li>
                                    <li>Akses dispenser air minum gratis di pinggir lapangan.</li>
                                </ul>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="fh-btn fh-btn-outline" data-bs-dismiss="modal">Tutup</button>
                                <a href="index.php?page=sewa&id=<?= $lapangan['id']; ?>" class="fh-btn fh-btn-primary">Langsung Booking</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>
