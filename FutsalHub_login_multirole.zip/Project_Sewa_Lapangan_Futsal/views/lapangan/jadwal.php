<section class="fh-page-head">
    <div class="container d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3">
        <div>
            <span class="fh-eyebrow">Jadwal Publik</span>
            <h1>Jadwal Penggunaan Lapangan</h1>
            <p>Cek jam yang sudah terpesan sebelum melakukan pemesanan agar jadwalmu tidak bentrok.</p>
        </div>
        <a href="index.php?page=lapangan" class="fh-btn fh-btn-primary">Pesan Lapangan</a>
    </div>
</section>

<section class="fh-section-sm">
    <div class="container">
        <div class="fh-table-wrap">
            <table class="fh-table">
                <thead>
                    <tr>
                        <th>Hari &amp; Tanggal</th>
                        <th>Waktu</th>
                        <th>Lapangan</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($data_pesanan)) : ?>
                        <tr><td colspan="4" class="fh-empty-row">Semua lapangan masih kosong. Yuk, jadi yang pertama booking!</td></tr>
                    <?php else : ?>
                        <?php foreach ($data_pesanan as $pesanan) :
                            $timestamp = strtotime($pesanan['tanggal_sewa']);
                            $daftar_hari = ['Sunday' => 'Minggu', 'Monday' => 'Senin', 'Tuesday' => 'Selasa', 'Wednesday' => 'Rabu', 'Thursday' => 'Kamis', 'Friday' => 'Jumat', 'Saturday' => 'Sabtu'];
                            $hari_indo = $daftar_hari[date('l', $timestamp)];

                            $jam_mulai = date('H:i', strtotime($pesanan['jam_mulai']));
                            $jam_selesai = date('H:i', strtotime($pesanan['jam_mulai'] . " +" . $pesanan['durasi_jam'] . " hours"));
                        ?>
                            <tr>
                                <td data-label="Tanggal"><div><span class="fh-cell-strong"><?= $hari_indo; ?></span><span class="fh-cell-sub"><?= date('d M Y', $timestamp); ?></span></div></td>
                                <td data-label="Waktu"><span class="fh-badge fh-badge-time"><?= $jam_mulai; ?> – <?= $jam_selesai; ?> WIB</span></td>
                                <td data-label="Lapangan"><span class="fh-cell-strong"><?= htmlspecialchars($pesanan['nama_lapangan']); ?></span></td>
                                <td data-label="Status"><div><span class="fh-badge fh-badge-booked">Terpesan</span><span class="fh-cell-sub">Oleh: Team <?= htmlspecialchars($pesanan['nama_pemesan']); ?></span></div></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
