<!-- HERO SECTION -->
<section class="fh-hero-wrap">
    <div class="fh-hero" style="background-image: url('https://images.unsplash.com/photo-1575361204480-aadea25e6e68?q=80&w=1200');">
        <div class="container fh-hero-inner">
            <span class="fh-hero-badge">Premium Futsal Arena</span>
            <h1>Main Futsal, <em>Tanpa Ribet.</em></h1>
            <p>Temukan lapangan favoritmu, pilih jadwal yang tersedia, dan pesan dengan lebih mudah melalui FutsalHub.</p>
            <div class="fh-hero-actions">
                <a class="fh-btn fh-btn-lime fh-btn-lg" href="index.php?page=lapangan">
                    Cari Lapangan
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                </a>
                <a class="fh-btn fh-btn-ghost-light fh-btn-lg" href="index.php?page=jadwal">Lihat Jadwal</a>
            </div>
        </div>
    </div>
</section>

<!-- FEATURES SECTION -->
<section class="fh-section">
    <div class="container">
        <div class="row align-items-end g-4 mb-5">
            <div class="col-lg-7">
                <span class="fh-eyebrow">Kenapa FutsalHub</span>
                <h2 class="fh-title">Mengapa harus booking di FutsalHub?</h2>
            </div>
            <div class="col-lg-5">
                <p class="fh-lead mb-0">Kami menyediakan fasilitas terbaik untuk kenyamanan pertandingan tim kamu.</p>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="fh-feature">
                    <span class="fh-feature-num">01</span>
                    <div class="fh-feature-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M12 5v14"/><circle cx="12" cy="12" r="3"/></svg>
                    </div>
                    <h3>Rumput &amp; Vinil Premium</h3>
                    <p>Pilihan lapangan rumput sintetis interlock dan vinil standar internasional yang empuk dan anti-slip demi mengurangi risiko cedera.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="fh-feature">
                    <span class="fh-feature-num">02</span>
                    <div class="fh-feature-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L4 14h7l-1 8 9-12h-7z"/></svg>
                    </div>
                    <h3>Konfirmasi Instan</h3>
                    <p>Bayar dengan QRIS atau transfer bank, lalu unggah bukti pembayaran langsung di form pemesanan.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="fh-feature">
                    <span class="fh-feature-num">03</span>
                    <div class="fh-feature-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.7V17h8v-2.3A7 7 0 0 0 12 2z"/></svg>
                    </div>
                    <h3>Pencahayaan LED Terang</h3>
                    <p>Sistem pencahayaan stadium yang terang di malam hari, membuat suasana main malam terasa seperti liga profesional.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA BANNER -->
<section class="pb-5 mb-5">
    <div class="container">
        <div class="fh-cta">
            <div>
                <span class="fh-eyebrow fh-eyebrow-light mb-2">Booking sekarang</span>
                <h2 class="mt-2">Siap Main Hari Ini?</h2>
                <p>Temukan lapangan yang sesuai dan rencanakan pertandinganmu bersama FutsalHub.</p>
            </div>
            <a href="index.php?page=lapangan" class="fh-btn fh-btn-lime fh-btn-lg">Pesan Lapangan</a>
        </div>
    </div>
</section>
